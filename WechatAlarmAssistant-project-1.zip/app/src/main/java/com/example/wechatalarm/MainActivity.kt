package com.example.wechatalarm

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var timePicker: TimePicker
    private lateinit var friendInput: EditText
    private lateinit var messageInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "微信定时助手"
            textSize = 25f
            gravity = Gravity.CENTER
        }, match())
        layout.addView(TextView(this).apply {
            text = "设置发送时间、微信好友备注名和消息内容。请先在微信中确认好友备注名唯一。"
            textSize = 14f
            setPadding(0, 18, 0, 14)
        }, match())
        timePicker = TimePicker(this).apply { setIs24HourView(true) }
        layout.addView(timePicker, match())
        friendInput = EditText(this).apply {
            hint = "微信好友备注名（需与微信列表显示一致）"
            singleLine = true
        }
        layout.addView(friendInput, match())
        messageInput = EditText(this).apply {
            hint = "要发送的文字"
            minLines = 3
            gravity = Gravity.TOP
        }
        layout.addView(messageInput, match())
        val save = Button(this).apply {
            text = "保存并设置闹钟"
            setOnClickListener { scheduleTask() }
        }
        layout.addView(save, match())
        val access = Button(this).apply {
            text = "开启无障碍服务设置"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(access, match())
        val exact = Button(this).apply {
            text = "精确闹钟权限设置"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 31) {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        layout.addView(exact, match())
        status = TextView(this).apply {
            text = "提示：当前版本是功能验证版。微信界面自动化受微信版本、系统锁屏和权限影响，不能保证无人值守发送成功。"
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }
        layout.addView(status, match())
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun scheduleTask() {
        val friend = friendInput.text.toString().trim()
        val message = messageInput.text.toString().trim()
        if (friend.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "请填写好友备注名和消息内容", Toast.LENGTH_SHORT).show()
            return
        }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, timePicker.hour)
            set(Calendar.MINUTE, timePicker.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        getSharedPreferences("tasks", MODE_PRIVATE).edit()
            .putString("friend", friend).putString("message", message)
            .putLong("time", cal.timeInMillis).apply()

        val intent = Intent(this, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        status.text = "已设置：${cal.get(Calendar.HOUR_OF_DAY)}:${"%02d".format(cal.get(Calendar.MINUTE))}，目标好友：$friend。首次请先手动测试无障碍服务。"
        Toast.makeText(this, "闹钟已设置", Toast.LENGTH_LONG).show()
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
