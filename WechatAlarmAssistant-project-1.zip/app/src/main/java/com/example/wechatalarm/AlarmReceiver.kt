package com.example.wechatalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.KeyguardManager
import android.widget.Toast

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("tasks", Context.MODE_PRIVATE)
        val friend = prefs.getString("friend", "") ?: ""
        val message = prefs.getString("message", "") ?: ""
        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (keyguard.isKeyguardLocked) {
            prefs.edit().putBoolean("pending_unlock", true).apply()
            return
        }
        WechatAccessibilityService.launchWechat(context, friend, message)
    }
}
