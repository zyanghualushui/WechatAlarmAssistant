package com.example.wechatalarm

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Handler
import android.os.Looper
import android.widget.Toast

class WechatAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var targetFriend = ""
    private var targetMessage = ""
    private var stage = 0

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != "com.tencent.mm" || stage == 0) return

        // 仅做界面辅助：尝试在微信当前可见界面中查找匹配好友文本。
        // 不读取聊天历史，也不尝试绕过微信验证或安全限制。
        val root = rootInActiveWindow ?: return
        if (stage == 1) {
            val nodes = root.findAccessibilityNodeInfosByText(targetFriend)
            if (nodes.isNotEmpty()) {
                nodes.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
                stage = 2
                handler.postDelayed({ trySendMessage() }, 900)
            }
        } else if (stage == 2) {
            trySendMessage()
        }
    }

    private fun trySendMessage() {
        val root = rootInActiveWindow ?: return
        val editables = ArrayList<AccessibilityNodeInfo>()
        collectEditables(root, editables)
        val input = editables.firstOrNull()
        if (input != null) {
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, targetMessage)
            }
            if (input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                // 不自动点击发送按钮；用户可先在自己的微信版本上验证输入框定位。
                stage = 0
                Toast.makeText(this, "消息已填入输入框，请检查后手动发送（当前验证版）", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun collectEditables(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        if (node.isEditable) out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectEditables(it, out) }
    }

    override fun onInterrupt() {}

    companion object {
        fun launchWechat(context: Context, friend: String, message: String) {
            val svc = current
            if (svc != null) {
                svc.targetFriend = friend
                svc.targetMessage = message
                svc.stage = 1
            }
            val launch = context.packageManager.getLaunchIntentForPackage("com.tencent.mm")
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                Toast.makeText(context, "已打开微信；自动化需在解锁状态且无障碍服务已启用", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "未检测到微信", Toast.LENGTH_LONG).show()
            }
        }
        @Volatile private var current: WechatAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
        val prefs = getSharedPreferences("tasks", Context.MODE_PRIVATE)
        if (prefs.getBoolean("pending_unlock", false)) {
            prefs.edit().putBoolean("pending_unlock", false).apply()
            val f = prefs.getString("friend", "") ?: ""
            val m = prefs.getString("message", "") ?: ""
            handler.postDelayed({ launchWechat(this, f, m) }, 1200)
        }
    }

    override fun onDestroy() {
        current = null
        super.onDestroy()
    }
}
